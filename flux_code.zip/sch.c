#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "nrutil.h"

double pi = 3.14159265358979323846264338327950;
int N = 512, jmax;
double *X_real, *X_img, *X, **eigvec, *eigval, **mat, **mat1, **eigvec1, *eigval1, *W_R, *W_I, *Cj, ext, delx = 0.1, hbar = 1.0, delt = 0.005, Ej = 3.395, El = 0.132, Ec = 0.479;
double x0, T, X_exact_R, X_exact_I, I_R, I_I, I_R1, I_I1, I_num, I_ext, IW_R, IW_I, I_ext1, IW_R1, IW_I1, w = 3.000365, delta1 = 1.273598, delta2 = 221.951654;
double error, error1;

void eigen(double **, double *, double **, int);
void ham(double *, double **);
void exp_V(double *, double *, int);
void exp_T(double *, double *, int);
void FFT(double *, double *, int, int);
void change(double *, int);

double pot(double i, double j)
{
    return 0.5 * El * i * i - Ej * cos(i - j);
}
FILE *fp, *fp1, *fp2, *fp3;
int main()
{
    clock_t start, end;
    start = clock();

    fp = fopen("sch-max.txt", "w");
    /*  fp1 = fopen("ext=0.5.txt", "r");
     fp2 = fopen("ext=0.25.txt", "r"); */
    /* fp3 = fopen("sch_ext.txt", "w"); */
    x0 = (N / 2 - 0.5) * -1 * delx;
    T = 0.0;
    jmax = 0;

    X_real = (double *)malloc(N * sizeof(double));
    Cj = (double *)malloc(N * sizeof(double));
    X_img = (double *)malloc(N * sizeof(double));
    W_I = (double *)malloc(N * sizeof(double));
    W_R = (double *)malloc(N * sizeof(double));

    double **mat = (double **)malloc(N * sizeof(double *));
    double **mat1 = (double **)malloc(N * sizeof(double *));
    for (int i = 0; i < N; i++)
    {
        mat[i] = (double *)malloc(N * sizeof(double));
        mat1[i] = (double *)malloc(N * sizeof(double));
    }

    X = (double *)malloc(N * sizeof(double));
    eigval = (double *)malloc(N * sizeof(double));
    eigvec = (double **)malloc(N * sizeof(double *));

    eigval1 = (double *)malloc(N * sizeof(double));
    eigvec1 = (double **)malloc(N * sizeof(double *));
    for (int i = 0; i < N; i++)
    {
        eigvec[i] = (double *)malloc(N * sizeof(double));
        eigvec1[i] = (double *)malloc(N * sizeof(double));
    }

    for (int i = 0; i < N; i++)
    {
        X[i] = x0 + i * delx;
    }
    ext = 0.5 * 2.0 * pi;
    ham(X, mat);
    eigen(mat, eigval, eigvec, N);

    ext = 0.25 * 2.0 * pi;
    ham(X, mat1);
    eigen(mat1, eigval1, eigvec1, N);

    /* for (int i = 0; i < N; i++)
    {
        fscanf(fp1, "%lf", &eigval[i]);
        fscanf(fp2, "%lf", &eigval1[i]);
        for (int j = 0; j < N; j++)
        {
            fscanf(fp1, "%lf", &eigvec[j][i]);
            fscanf(fp2, "%lf", &eigvec1[j][i]);
        }
        fscanf(fp1, "\n");
        fscanf(fp2, "\n");
    }
    fclose(fp1);
    fclose(fp2); */

    /*  for (double delta2 = 221.9; delta2 <= 222.0; delta2 = delta2 + 1.0e-006)
     { */
    error = 0.0;
    T = 0.0;
    I_I = 0.0;
    I_R = 0.0;
    for (int i = 0; i < N; i++)
    {
        X_real[i] = eigvec[0][i] / sqrt(delx);
        X_img[i] = 0;
    }
    while (T <= 400.0)
    {

        ext = -0.25 * pi * (tanh(1.0 / w * (T - (50 - (delta1 / 2.0)))) + tanh(1.0 / w * (50 + (delta1 / 2.0) - T))) +
              0.25 * pi * (tanh(1.0 / w * (T - (50 + (delta1 / 2.0) + delta2))) + tanh(1 / w * ((50 + 1.5 * delta1 + delta2) - T))) + pi;
        exp_V(X_real, X_img, N);
        FFT(X_real, X_img, N, 1);
        exp_T(X_real, X_img, N);
        FFT(X_real, X_img, N, -1);
        exp_V(X_real, X_img, N);
        T = T + delt;
    }
    for (int q = 0; q < N; q++)
    {

        I_R += delx * (eigvec[1][q] / sqrt(delx) * X_real[q]);
        I_I += delx * (eigvec[1][q] / sqrt(delx) * X_img[q]);
    }

    error = pow(I_R, 2.0) + I_I * I_I;

    fprintf(fp, "w=%e  delta1%e delta2=%.08e P=%.16e\n ", w, delta1, delta2, error);
    /*  } */
    /* for (double t = 0; t <= 220.0 + 70.0; t = t + 0.1)
    {
        ext = -0.25 * pi * (tanh(1 / w * (t - (50 - (delta1 / 2)))) + tanh(1 / w * (50 + (delta1 / 2) - t))) +
              0.25 * pi * (tanh(1 / w * (t - (50 + (delta1 / 2) + 220.0))) + tanh(1 / w * ((50 + 1.5 * delta1 + 220.0) - t))) + pi;
        fprintf(fp3, "%e %e\n ", t, ext);
    } */

    end = clock();
    float time = (end - start) / CLOCKS_PER_SEC;
    fprintf(fp, "\nT=%e, delt=%e, time = %f\n", T, delt, time);
}

void exp_V(double *X_real, double *X_img, int N)
{
    double real, img, V;
    for (int i = 0; i < N; i++)
    {
        V = -1.0 * pot(X[i], ext) * delt / 2.0 / hbar;
        real = cos(V) * X_real[i] - sin(V) * X_img[i];
        img = cos(V) * X_img[i] + sin(V) * X_real[i];
        X_real[i] = real;
        X_img[i] = img;
    }
}

void exp_T(double *X_real, double *X_img, int N)
{
    double real, img, T, l;
    for (int i = 0; i < N; i++)
    {
        l = i;
        if (i > N / 2)
        {
            l = i - N;
        }
        T = -1.0 * delt * hbar * 4.0 * Ec * pow(l * 2.0 * pi / N / delx, 2.0);
        real = cos(T) * X_real[i] - sin(T) * X_img[i];
        img = cos(T) * X_img[i] + sin(T) * X_real[i];
        X_real[i] = real;
        X_img[i] = img;
    }
}

void FFT(double *x, double *y, int n, int sign)
{
    int i, j, k, l, m, n1, n2;
    double c, c1, e, s, s1, t, tr, ti;
    for (j = 1, i = 1; i < 16; i++)
    {
        m = i;
        j = 2 * j;
        if (j == n)
        {
            break;
        }
    }
    n1 = n - 1;
    for (j = 0, i = 0; i < n1; i++)
    {
        if (i < j)
        {
            tr = x[j];
            ti = y[j];
            x[j] = x[i];
            y[j] = y[i];
            x[i] = tr;
            y[i] = ti;
        }
        k = n / 2;
        while (k < (j + 1))
        {
            j = j - k;
            k = k / 2;
        }
        j = j + k;
    }
    n1 = 1;
    for (l = 1; l <= m; l++)
    {
        n1 = 2 * n1;
        n2 = n1 / 2;
        e = pi / n2;
        c = 1.0;
        s = 0.0;
        c1 = cos(e);
        s1 = -sign * sin(e);
        for (j = 0; j < n2; j++)
        {
            for (i = j; i < n; i += n1)
            {
                k = i + n2;
                tr = c * x[k] - s * y[k];
                ti = c * y[k] + s * x[k];
                x[k] = x[i] - tr;
                y[k] = y[i] - ti;
                x[i] = x[i] + tr;
                y[i] = y[i] + ti;
            }
            t = c;
            c = c * c1 - s * s1;
            s = t * s1 + s * c1;
        }
    }
    if (sign == -1)
    {
        for (i = 0; i < n; i++)
        {
            x[i] /= n;
            y[i] /= n;
        }
    }
}
void ham(double *X, double **mat)
{
    double delK2, ci, k;

    int i, j;

    for (i = 0; i < N; ++i)
    {
        for (j = 0; j < N; ++j)
        {
            mat[i][j] = 0.0;

            for (k = 1.0; k <= N / 2 - 1; ++k)
            {
                mat[i][j] += cos(k * 2.0 * pi * (i - j) / N) * (16.0 * Ec) * pow(hbar * pi * k / N / delx, 2);
            }
            mat[i][j] += 0.5 * pow(-1.0, i - j) * (16.0 * Ec) * pow(hbar * pi * N / 2 / N / delx, 2);
            mat[i][j] *= 2.0 / N;
        }
        mat[i][i] += pot(X[i], ext);
    }
}
void eigen(double **mat, double *eigval, double **eigvec, int dim)
{

    void jacobi(double **, int, double[], double **, int *);
    void indexx(int, double[], int[]);

    int i, j, k, ic, *dex;
    double *vec1;
    double **mat1, **mat2, **mat3;

    dex = ivector(1, dim); // integer vector
    vec1 = vector(1, dim);
    mat2 = matrix(1, dim, 1, dim);
    mat3 = matrix(1, dim, 1, dim);

    for (i = 1; i <= dim; i++)
    {
        for (j = 1; j <= dim; j++)
        {
            mat2[i][j] = mat[i - 1][j - 1];
        }
    }
    jacobi(mat2, dim, vec1, mat3, &ic);
    indexx(dim, vec1, dex);
    for (i = 1; i <= dim; i++)
    {
        eigval[i - 1] = vec1[dex[i]];
        for (j = 1; j <= dim; j++)
        {
            eigvec[i - 1][j - 1] = mat3[j][dex[i]];
        }
    }

    free_matrix(mat2, 1, dim, 1, dim);
    free_matrix(mat3, 1, dim, 1, dim);
    free_vector(vec1, 1, dim);
    free_ivector(dex, 1, dim);

    return;
}