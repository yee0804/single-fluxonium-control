#include "common.h"

extern double t,dt;
extern double **rho,**Had,**Hgrid,**Hadd;
extern double **sigmap,**sigmam;
extern double **sigmaz;
extern double rate,rate2;
extern double **Mat,*eigval,**trans,**inv_trans,**ptrans;/** for diag, eigval, w, w^-1,w(t-dt) **/
extern double **diag;//D-matrix after diag(Hgrid)
extern double phi_ext,dphi_ext,pphi_ext;
extern double *phiext_read,*Eg,*E1,*noncoup;

extern FILE *fp1,*fp2,*fp3;


void tdep_H(int dim,int ms_dim)
{
	/*- dim=grid space dim, ad_dim=master eq dim  -*/
    int i,j,k,indx1;
    double **nonadia,**dtrans;
    double inn,dot_phiext;
    nonadia=matrix(0,ms_dim-1,0,ms_dim-1);
    dtrans=matrix(0,ms_dim-1,0,ms_dim-1);
    
    phi_ext=external_flux();
    if(t<dt) {dot_phiext=0;}
    else {dot_phiext=(phi_ext-pphi_ext)/dt;}
    
	indx1=(int)floor(phi_ext/dphi_ext);	
	diag[0][0]=linear_interpolation(phi_ext,phiext_read[indx1],phiext_read[indx1+1],Eg[indx1],Eg[indx1+1]);
	diag[1][1]=linear_interpolation(phi_ext,phiext_read[indx1],phiext_read[indx1+1],E1[indx1],E1[indx1+1]);
	nonadia[0][0]=linear_interpolation(phi_ext,phiext_read[indx1],phiext_read[indx1+1],noncoup[4*indx1],noncoup[4*(indx1+1)]);
	nonadia[0][1]=linear_interpolation(phi_ext,phiext_read[indx1],phiext_read[indx1+1],noncoup[4*indx1+1],noncoup[4*(indx1+1)+1]);
	nonadia[1][0]=linear_interpolation(phi_ext,phiext_read[indx1],phiext_read[indx1+1],noncoup[4*indx1+2],noncoup[4*(indx1+1)+2]);
	nonadia[1][1]=linear_interpolation(phi_ext,phiext_read[indx1],phiext_read[indx1+1],noncoup[4*indx1+3],noncoup[4*(indx1+1)+3]);
    for(j=0;j<ms_dim;j++)
    {
        for(k=0;k<ms_dim;k++){nonadia[j][k]*=dot_phiext;}
    }

  //  /* Hgrid */
  //  Hamiltonian(Hgrid,dim);
  //  
  //  /*- construc adiabatic Hamiltonian Had= D-ih w^-1*dw/dt -*/
  //  
  //  //cal w(t)
  //  eigen(Hgrid,eigval,trans,dim);
  //  //check eigvector phase
  //  inn=0.;
  //  for(i=0;i<dim;i++)
  //  {
  //      inn=0;
  //      for(j=0;j<dim;j++)
  //      {
  //       	inn+=ptrans[j][i]*trans[j][i];
  //      }
  //      if(inn<0) for(j=0;j<dim;j++) {trans[j][i]*=(-1.);}
  //  }
  // 
  //  
  //  
  //  //D matrix
  //  for(j=0;j<ms_dim;j++){
  //      for(k=0;k<ms_dim;k++){
  //          diag[j][k]=0.;
  //          if(j==k) {diag[j][k]=eigval[j];}
  //      }
  //  }


    //w^-1=w^T
  //  Transpose(trans,inv_trans,dim);
  //  
  //  //(w^-1)*(dw/dt) = (I-(w^-1)*w(t-dt))/dt
  //  Mat_Multiply(inv_trans,ptrans,nonadia,dim);
  //  for(j=0;j<dim;j++){
  //      for(k=0;k<dim;k++){
  //       	if(j==k) { nonadia[j][k]=(1.-nonadia[j][k])/dt;}
  //       	else{nonadia[j][k]=-nonadia[j][k]/dt;}
  //      }
  //  }
    
    //Hiad(adiabatic)
    for(j=0;j<ms_dim;j++){
        for(k=0;k<ms_dim;k++){
            Had[j][2*k]=0;Had[j][2*k+1]=0.;
            if(j==k) {Had[j][2*k]=diag[j][k];}
            else {Had[j][2*k+1]=-hbar*nonadia[j][k];}
        }
    }
    
    pphi_ext=phi_ext;
   
//    fprintf(fp1,"%e %e %e %e %e %e %e %e %e \n",t,Had[0][0],Had[0][1],Had[0][2],Had[0][3],Had[1][0],Had[1][1],Had[1][2],Had[1][3]);

    


    free_matrix(nonadia,0,ms_dim-1,0,ms_dim-1);
    free_matrix(dtrans,0,dim-1,0,dim-1);

	return;
}

void RHS_master_eq(double **meRHS,int dim)
{
/* drho=-i/hbar[H,rho]+decay  */
/* this function construct RHS of eq. */
    int i,j,k;
    double **mat1,**mat2,**mat3;
    
    double inn;
    mat1=matrix(0,dim-1,0,2*dim-1);
    mat2=matrix(0,dim-1,0,2*dim-1);
    mat3=matrix(0,dim-1,0,2*dim-1);
   

    /*[H,rho]*/
    Dagger(Had,Hadd,dim);
    Complex_Mat_Multiply(Had,rho,mat1,dim);
    Complex_Mat_Multiply(rho,Had,mat2,dim);
    
    for(i=0;i<dim;i++)
    {
        for(j=0;j<dim;j++){
        	 meRHS[i][2*j]=(mat1[i][2*j+1]-mat2[i][2*j+1])/hbar;
        	 meRHS[i][2*j+1]=-(mat1[i][2*j]-mat2[i][2*j])/hbar;
        }
    }
 
    /** decay terms **/
 
 	//relaxation
    three_Complex_Mat_Multiply(sigmam,rho,sigmap,mat1,dim); 
    three_Complex_Mat_Multiply(sigmap,sigmam,rho,mat2,dim); 
    three_Complex_Mat_Multiply(rho,sigmap,sigmam,mat3,dim); 
 
    for(i=0;i<dim;i++)
    {
        for(j=0;j<dim;j++){
	 	   meRHS[i][2*j]+=rate*(mat1[i][2*j]-0.5*mat2[i][2*j]-0.5*mat3[i][2*j]);
	 	   meRHS[i][2*j+1]+=rate*(mat1[i][2*j+1]-0.5*mat2[i][2*j+1]-0.5*mat3[i][2*j+1]);
        }
    }

	//pure dephasing
    three_Complex_Mat_Multiply(sigmaz,rho,sigmaz,mat1,dim); 
	rate2=dephasing_rate();
    for(i=0;i<dim;i++)
    {
        for(j=0;j<dim;j++){
	 	   meRHS[i][2*j]+=rate2/2.*(mat1[i][2*j]-rho[i][2*j]);
	 	   meRHS[i][2*j+1]+=rate2/2.*(mat1[i][2*j+1]-rho[i][2*j+1]);
        }
    }

    
    free_matrix(mat1,0,dim-1,0,2*dim-1);
    free_matrix(mat2,0,dim-1,0,2*dim-1);
    free_matrix(mat3,0,dim-1,0,2*dim-1);

    return;
}

void Dot_Diffeq(double *X,double *kcoeff,int dim)
{

     int i,j,k; 
     double** meRHS=matrix(0,dim-1,0,2*dim-1);
    
     for(i=0;i<dim;i++)
     {
         for(j=0;j<dim;j++)
         {
             rho[i][2*j]=X[i*2*dim+2*j];
             rho[i][2*j+1]=X[i*2*dim+2*j+1];
         }
     }
    
     RHS_master_eq(meRHS,dim);
    

    for(i=0;i<dim;i++)
    {
        for(j=0;j<dim;j++){
            kcoeff[i*2*dim+2*j]=meRHS[i][2*j];
            kcoeff[i*2*dim+2*j+1]=meRHS[i][2*j+1];
        }
    }
    
    free_matrix(meRHS,0,dim-1,0,2*dim-1);

    return;
}


void RK4_solver(double*X,double dt,int dim)
{
    int i,j,k;
    double *xi,*k1,*k2,*k3,*k4;
    xi=vector(0,2*dim*dim-1);
    k1=vector(0,2*dim*dim-1);
    k2=vector(0,2*dim*dim-1);
    k3=vector(0,2*dim*dim-1);
    k4=vector(0,2*dim*dim-1);

    
    Dot_Diffeq(X,k1,dim);
    for(j=0;j<2*dim*dim;j++) {xi[j]=X[j]+0.5*k1[j]*dt;}
    Dot_Diffeq(xi,k2,dim);
    for(j=0;j<2*dim*dim;j++) {xi[j]=X[j]+0.5*k2[j]*dt;}
    Dot_Diffeq(xi,k3,dim);
    for(j=0;j<2*dim*dim;j++) {xi[j]=X[j]+k3[j]*dt;}
    Dot_Diffeq(xi,k4,dim);

    t+=(dt);

    for(j=0;j<2*dim*dim;j++)
    {
	X[j]+=dt*(k1[j]+2*k2[j]+2*k3[j]+k4[j])/6.;
    }


    free_vector(xi,0,2*dim*dim-1);
    free_vector(k1,0,2*dim*dim-1);
    free_vector(k2,0,2*dim*dim-1);
    free_vector(k3,0,2*dim*dim-1);
    free_vector(k4,0,2*dim*dim-1);
    
    return;
}

double dephasing_rate()
{
	double rra,T2;
	double AA,rr,ss,cc,ss2,BB;

	if(fabs(phi_ext-0.5*2*pi)>1e-4){
		AA=0.0311685;rra=0.000131847;ss=2.22338e-06;cc=51.6949 ;ss2=9.73234e-05 ;BB=1.02683 ;
		T2=AA * (rra / (pow(phi_ext,2) + rra*rra))*exp(-pow(phi_ext,2)/(2*ss)) +BB*exp(-pow(phi_ext,2)/(2*ss2)) +cc ;
	}
	else
	{
	//	AA=0.0211453;rra=9.71871e-05;ss=1.38315e-06;cc=84.6192 ;ss2=9.93803e-05 ;BB=1.01993 ;
		T2=10;
	}
	//T2 is in mu s
	T2*=1e3*2*pi;//to ns
	fprintf(fp3,"%e %e %e\n",t,phi_ext,T2/1e3);

	//1/T2=1/(2T1)+1/T_phi
	rr=1./T2-0.5*rate;//mu s

	
	




	return rr;
}
