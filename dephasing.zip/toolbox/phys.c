#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "nrutil.h" 
#include "../common.h"

extern double phi_ext,t;
extern double *H0eig1,*H0eig2;
extern FILE *fpphi;
extern double D2;

double external_flux()
{
	double flux;
//	double T1,T2,T3,D,a1,a2;
   

   // a1=1/3.054038959234077;
   // a2=1/1.619791703359615;
   // D=3.6;
//   a1=1./3.013338021466468;
//   a2=1./1.729179149397758;
//   D=3.66078332308184;
//    D2=3.5;

//    T1=100;T2=T1+D;T3=T2+D2;
//
//  
//	flux=0.5*2.*pi/2.*(tanh(a1*(t-T1))+tanh(a1*(T2-t)))+0.25*2.*pi/2.*(tanh(a2*(t-T3))+1.)+0.25*2.*pi;


//	a1=0.01/2./pi;
//    flux=0.25*pi*(tanh(a1*(t-T/2.))+1)+0.25*2*pi;

	/*X-gate our*/
//	double a1,a2,a3,a4,d1,d2,T1,tt,T2,T3,Tp;
//	a1=1./3.;a2=1./3.;a3=1./3.;a4=1./8.156443862091166;
//	d1=1.280783513575486;d2=3.816483823470961;
//	T1=50;tt=T1-(d1/2.);T2=T1+(d1/2.);T3=T2+d2;Tp=T2+(d2/2.);
//
//	flux=(-(tanh(a1*(t-tt))+tanh(a2*(T2-t)))+(tanh(a3*(t-T2))+tanh(a4*(T3-t))))*0.25*pi+0.5*2*pi;

	/*X-gate Schuster*/
	double w,delta,delta2;
	w=3.000365;
	delta=1.273598;
	delta2=221.951654;

	flux=(-0.25*pi*(tanh((1/w)*(t-(50-delta/2.)))+tanh((1/w)*((50+delta/2.)-t)))+0.25*pi*(tanh((1/w)*(t-(50+delta/2.+delta2)))+tanh((1/w)*((50+1.5*delta+delta2)-t)))+pi);	
   


   fprintf(fpphi,"%e %.14e\n",t,flux);
    
    
	return flux;
}

void Hamiltonian(double **Ham,int dim)
{
	/*----------------  fluxonium Hamiltonian -----------------------*/
	/*-  H=4Ecn^2+0.5*EL\phi^2-EJcos(\phi+\phi_ext)                 -*/
	/*-  this function construct fluxonium's H in \phi grid space   -*/
	/*-  index start from 0                                         -*/
	/*---------------------------------------------------------------*/


    int i,j,l;
    int nss=((dim-1)/2);
    double dx=(xmax-xmin)/(dim-1);
    /* xi=xmin+i*dx */

    double *pot=vector(0,dim-1);
    double *x=vector(0,dim-1);

    /** set grid space **/
    for(i=0;i<dim;i++)
    {
        x[i]=xmin+i*dx;
    }
    /** V(x) **/
    Potential(pot,x,dim);
    /** <x|H|x> **/
    for(i=0;i<dim;i++)
    {
        for(j=0;j<dim;j++)
        {
            Ham[i][j]=0.;
            for(l=1;l<=nss;l++)
            {
				Ham[i][j]+=cos(l*2.*pi*(i-j)/dim)*4.*Ec*pow(2.*pi*l/dim/dx,2);
            }
            Ham[i][j]*=(2./dim);
            if(i==j)
            {
                Ham[i][j]+=pot[i];
            }
        }
    }



    free_vector(pot,0,dim-1);
    free_vector(x,0,dim-1);

    
    return;
}

void Potential(double *V,double *x,int dim)
{
	int i;
	phi_ext=external_flux();
    for(i=0;i<dim;i++)
    {
        V[i]=0.5*EL*x[i]*x[i]-EJ*cos(x[i]+phi_ext);
    }

    return;
}

void Tindep_H0(double** H0,int n,int dim)
{
	/*-------------- fluxonium H0 ------------------ -*/
	/* H=H0+H',H0=4Ec n^2,H'=0.5EL\phi^2-EJcos(\phi+phi_ext) -*/
	/* this function construct H0 in eigenspace              -*/
	/* n=master eq dim, dim=grid space dim                   -*/

    int i,j,l;
    int nss=((dim-1)/2);
    double dx=(xmax-xmin)/(dim-1);
    /* xi=xmin+i*dx */

    double *x=vector(0,dim-1);
    double **Ham=matrix(0,dim-1,0,2*dim-1);
	double **eigvec=matrix(0,dim-1,0,2*dim-1);
	double *eigval=vector(0,dim-1);
	double ele[2];

    /** set grid space **/
    for(i=0;i<dim;i++)
    {
        x[i]=xmin+i*dx;
    }
    /** <x|H0|x> **/
    for(i=0;i<dim;i++)
    {
        for(j=0;j<dim;j++)
        {
            Ham[i][2*j]=0.;Ham[i][2*j+1]=0;
            for(l=1;l<=nss;l++)
            {
				Ham[i][2*j]+=cos(l*2.*pi*(i-j)/dim)*4.*Ec*pow(2.*pi*l/dim/dx,2);
            }
            Ham[i][2*j]*=(2./dim);
        }
    }

	/** eigenvector of H0 **/
    Hermitian_eigen(Ham,eigval,eigvec,dim);

	for(i=0;i<dim;i++){
		H0eig1[2*i]=eigvec[i][2*0];H0eig1[2*i+1]=eigvec[i][2*0+1];
		H0eig2[2*i]=eigvec[i][2*1];H0eig2[2*i+1]=eigvec[i][2*1+1];

	}


	/** H0 in eigen space  **/
	bracket_expectation(H0eig1,H0eig1,Ham,ele,dim);
	H0[0][0]=ele[0];H0[0][1]=ele[1];
	bracket_expectation(H0eig1,H0eig2,Ham,ele,dim);
	H0[0][2]=ele[0];H0[0][3]=ele[1];
	H0[1][0]=H0[0][2];H0[1][1]=-H0[0][3];
	bracket_expectation(H0eig2,H0eig2,Ham,ele,dim);
	H0[1][2]=ele[0];H0[1][3]=ele[1];




    free_vector(x,0,dim-1);
	free_matrix(Ham,0,dim-1,0,dim-1);
	free_matrix(eigvec,0,dim-1,0,dim-1);
	free_vector(eigval,0,dim-1);


	return;
}


void Tdep_Hp(double **Ht,int n,int dim)
{
    int i,j,l;
    int nss=((dim-1)/2);
    double dx=(xmax-xmin)/(dim-1);
	double ele[2];
    double *x=vector(0,dim-1);
    double *pot=vector(0,dim-1);
    double *temp=vector(0,2*2*dim-1);
    /* xi=xmin+i*dx */

    /** set grid space **/
    for(i=0;i<dim;i++)
    {
        x[i]=xmin+i*dx;
    }
    
	/** V(x) **/
    Potential(pot,x,dim);

	/** V in eigen space **/
	bracket_expectation_daigO(H0eig1,H0eig1,pot,ele,dim);
	Ht[0][0]=ele[0];Ht[0][1]=ele[1];
	bracket_expectation_daigO(H0eig1,H0eig2,pot,ele,dim);
	Ht[0][2]=ele[0];Ht[0][3]=ele[1];
	Ht[1][0]=Ht[0][2];Ht[1][1]=-Ht[0][3];
	bracket_expectation_daigO(H0eig1,H0eig2,pot,ele,dim);
	Ht[1][2]=ele[0];Ht[1][3]=ele[1];

	
	



    free_vector(x,0,dim-1);
    free_vector(pot,0,dim-1);
    free_vector(temp,0,2*dim-1);

	return;
}
