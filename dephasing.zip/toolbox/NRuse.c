#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "nrutil.h" 

void Hermitian_eigen(double **mat,double *Eigval,double **Eigvec,int N)
{
    //input M : M[i][2*j]=real part, M[i][2*j+1]=imag part
    //ref: NR(2nd) p.482, eq(11.4.2)
    int i,j,k,ic,*dex;
    void jacobi(double **, int , double [], double **, int *);
    void indexx(int , double [], int []);
    double *vec1;
    double **mat2,**mat3;
    double **M;//input
    
    
    dex=ivector(1,2*N);//integer vector
    vec1=vector(1,2*N);
    mat2=matrix(1,2*N,1,2*N);
    mat3=matrix(1,2*N,1,2*N);
    M=matrix(1,2*N,1,2*N);

    /* prepare input (2Nx2N) matrix */
    for(i=0;i<N;i++)
    {
	for(j=0;j<N;j++)
	{
	    M[i+1][j+1]=mat[i][2*j];
	    M[N+i+1][N+j+1]=mat[i][2*j];
	    M[i+1][N+j+1]=(-mat[i][2*j+1]);
	    M[N+i+1][j+1]=mat[i][2*j+1];
	}

    }
    
    /* inside */
    
    for(i=1;i<=2*N;i++)
    {
        for(j=1;j<=2*N;j++)
        {
            mat2[i][j]=M[i][j];
        }
    }
    jacobi(mat2, 2*N, vec1, mat3, &ic);
    indexx(2*N, vec1, dex);
    
    /*copy to outside arrays*/
    for(i=1;i<=N;i++) Eigval[i-1]=vec1[dex[2*i]];
    for(i=1;i<=N;i++)
    {
        for(j=1;j<=N;j++)
        {
            Eigvec[j-1][2*(i-1)]=mat3[j][dex[2*i]];
            Eigvec[j-1][2*(i-1)+1]=mat3[N+j][dex[2*i]];
        }
        
    }
	//Eigvec[i][2*j]=j-th vector i-th element
    
    /* inside ends */
    
    
    free_matrix(mat2,1,2*N,1,2*N);
    free_matrix(mat3,1,2*N,1,2*N);
    free_matrix(M,1,2*N,1,2*N);
    free_vector(vec1,1,2*N);
    free_ivector(dex,1,2*N);

    
    
    return;






    return;
}

void eigen(double **M,double *Eigval,double **Eigvec,int N)
{
    //input Mat from 0~N-1
    //output eigval,eigvec are sort
    //Jacobi,indexx from NR2
    int i,j,k,ic,*dex;
    void jacobi(double **, int , double [], double **, int *);
    void indexx(int , double [], int []);
    double *vec1;
    double **mat2,**mat3;
    
    
    dex=ivector(1,N);//integer vector
    vec1=vector(1,N);
    mat2=matrix(1,N,1,N);
    mat3=matrix(1,N,1,N);
    
    /* inside */
    
    for(i=1;i<=N;i++)
    {
        for(j=1;j<=N;j++)
        {
            mat2[i][j]=M[i-1][j-1];
        }
    }
    jacobi(mat2, N, vec1, mat3, &ic);
    indexx(N, vec1, dex);
    
    /*copy to outside arrays*/
    for(i=1;i<=N;i++)
    {
        Eigval[i-1]=vec1[dex[i]];
        for(j=1;j<=N;j++)
        {
            Eigvec[j-1][i-1]=mat3[j][dex[i]];
//            Eigvec[(i-1)*N+(j-1)]=mat3[j][dex[i]];
        }
        
    }
    
    /* inside ends */
    
    
    free_matrix(mat2,1,N,1,N);
    free_matrix(mat3,1,N,1,N);
    free_vector(vec1,1,N);
    free_ivector(dex,1,N);

    
    
    return;
}

void nr_inverse(double **Mat,int N)
{
    //Mat replaced by inv(Mat)
    //input mat from 0~N-1
    //gaussj from NR2
    void gaussj(double **,int ,double **,int );
    
    int i,j,k;
    double **mat1,**mat2;
    mat1=matrix(1,N,1,N);
    mat2=matrix(1,N,1,N);
    
    for(i=1;i<=N;i++)
    {
        for(j=1;j<=N;j++)
        {
            mat1[i][j]=Mat[i-1][j-1];
        }
    }
    
    
    
    gaussj(mat1,N,mat2,N);
    
    
    for(i=1;i<=N;i++)
    {
        for(j=1;j<=N;j++)
        {
            Mat[i-1][j-1]=mat1[i][j];
        }
    }
    
    free_matrix(mat1,1,N,1,N);
    free_matrix(mat2,1,N,1,N);
    
    
    return;
}

