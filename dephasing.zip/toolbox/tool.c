#include <stdlib.h>
#include <math.h>
#include "nrutil.h" 

void Complex_vec_inner(double *vec1,double *vec2,double *res,int N)
{
	int i,j;
	res[0]=0;res[1]=0;
	for(i=0;i<N;i++) res[0]+=(vec1[2*i]*vec2[2*i]+vec1[2*i+1]*vec2[2*i+1]);
	for(i=0;i<N;i++) res[1]+=(vec1[2*i]*vec2[2*i+1]-vec1[2*i+1]*vec2[2*i]);

	return;
}

void Mat_Multiply(double **A,double **B,double **C,int N)
{ /* C=A*B ,A,B,C are real matrix*/
    
    int i,j,k;
    	
    for(i=0;i<N;i++)
    {
		for(j=0;j<N;j++)
		{
		    C[i][j]=0;
		    for(k=0;k<N;k++)
		    {
				C[i][j]+=A[i][k]*B[k][j];
		    }
		}
    }
    
    return;
}

void Complex_Mat_Multiply(double **A,double **B,double **C,int N)
{ /* C=A*B ,A,B,C are complex matrix*/

   int i,j,k;
    
   for(i=0;i<N;i++)
   {
       for(j=0;j<N;j++)
       {
           C[i][2*j]=0;C[i][2*j+1]=0;
           for(k=0;k<N;k++)
           {
	   	    	C[i][2*j]+=(A[i][2*k]*B[k][2*j]-A[i][2*k+1]*B[k][2*j+1]);
				C[i][2*j+1]+=(A[i][2*k]*B[k][2*j+1]+A[i][2*k+1]*B[k][2*j]);
           }
       }
   }

    return;
}


void three_Mat_Multiply(double **A,double **B,double **C,double **D,int N)
{ /* D=A*B*C ,A,B,C,D are real matrix*/
    
    int i,j,k;
    double **temp;
    temp=matrix(0,N-1,0,N-1);
    
    	
    for(i=0;i<N;i++)
    {
	for(j=0;j<N;j++)
	{
	    temp[i][j]=0;
	    for(k=0;k<N;k++)
	    {
			temp[i][j]+=A[i][k]*B[k][j];
	    }
	}
    }
    for(i=0;i<N;i++)
    {
		for(j=0;j<N;j++)
		{
		    D[i][j]=0;
		    for(k=0;k<N;k++)
		    {
				D[i][j]+=temp[i][k]*C[k][j];
		    }
		}
    }
    
    free_matrix(temp,0,N-1,0,N-1);

    return;
}

void three_Complex_Mat_Multiply(double **A,double **B,double **C,double **D,int N)
{ /* D=A*B*C ,A,B,C,D are complex matrix*/
    
    int i,j,k;
    double **temp;
    temp=matrix(0,N-1,0,2*N-1);
    
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            temp[i][2*j]=0;temp[i][2*j+1]=0;
            for(k=0;k<N;k++)
            {
    	    	temp[i][2*j]+=(A[i][2*k]*B[k][2*j]-A[i][2*k+1]*B[k][2*j+1]);
   		      	temp[i][2*j+1]+=(A[i][2*k]*B[k][2*j+1]+A[i][2*k+1]*B[k][2*j]);
            }
        }
    }
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            D[i][2*j]=0;D[i][2*j+1]=0;
            for(k=0;k<N;k++)
            {
    	    	D[i][2*j]+=(temp[i][2*k]*C[k][2*j]-temp[i][2*k+1]*C[k][2*j+1]);
       		  	D[i][2*j+1]+=(temp[i][2*k]*C[k][2*j+1]+temp[i][2*k+1]*C[k][2*j]);
            }
        }
    }
    	
    
    free_matrix(temp,0,N-1,0,2*N-1);

    return;
}


void bracket_expectation(double *vec1,double *vec2,double **Operator,double *expect,int N)
{
	/* <vec1|Operator|vec2> */
	/* vec and Operator are complex*/
	
	int i,j;
	double *temp=vector(0,2*N-1);

	for(i=0;i<N;i++)
	{
		temp[2*i]=0;temp[2*i+1]=0;
		for(j=0;j<N;j++){
			temp[2*i]+=(vec1[2*j]*Operator[j][2*i]+vec1[2*j+1]*Operator[j][2*i+1]);
			temp[2*i+1]+=(vec1[2*j]*Operator[j][2*i+1]-vec1[2*j+1]*Operator[j][2*i]);
		}
	}
	
	expect[0]=0;expect[1]=0;
	for(i=0;i<N;i++)
	{
		expect[0]+=(temp[2*i]*vec2[2*i]-temp[2*i+1]*vec2[2*i+1]);
		expect[1]+=(temp[2*i]*vec2[2*i+1]+temp[2*i+1]*vec2[2*i]);
	}


	free_vector(temp,0,2*N-1);
	return;
}

void bracket_expectation_daigO(double *vec1,double *vec2,double *Operator,double *expect,int N)
{
	/* for case Operator is real diagonal matrix */
	/* <vec1|Operator|vec2>                */
	/* vec and Operator are complex        */

	int i,j;
	double *temp=vector(0,2*N-1);

	for(i=0;i<N;i++)
	{
		temp[2*i]=(vec1[2*i]*Operator[i]);
		temp[2*i+1]=(-vec1[2*i+1]*Operator[i]);
	}

	expect[0]=0;expect[1]=0;
	for(i=0;i<N;i++)
	{
		expect[0]+=(temp[2*i]*vec2[2*i]-temp[2*i+1]*vec2[2*i+1]);
		expect[1]+=(temp[2*i]*vec2[2*i+1]+temp[2*i+1]*vec2[2*i]);
	}


	free_vector(temp,0,2*N-1);



	return;
}

void Dagger(double **mat,double **mat_dag,int N)
{
    int i,j;

    for(i=0;i<N;i++)
    {
		for(j=0;j<N;j++)
		{
		    mat_dag[i][2*j]=mat[j][2*i];
		    mat_dag[i][2*j+1]=-mat[j][2*i+1];
		}
    }

    return;
}

void Transpose(double **mat,double **mat_T,int N)
{
    int i,j;

    for(i=0;i<N;i++)
    {
		for(j=0;j<N;j++)
		{
		    mat_T[i][j]=mat[j][i];
		}
    }

    return;
}

double linear_interpolation(double x,double x1,double x2,double y1,double y2)
{
	/* x1,x2,y1,y2 given, xy target */
	double y;
	
	y=y1+(y2-y1)/(x2-x1)*(x-x1);

	return y;
}
