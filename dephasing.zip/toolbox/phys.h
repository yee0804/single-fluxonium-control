#ifndef _PHYS_H_
#define _PHYS_H_

double external_flux();

void Hamiltonian(double **,int );

void Potential(double *,double *,int);

void Tindep_H0(double** ,int ,int);

void Tdep_Hp(double **,int ,int );

#endif /* _PHYS_H_ */
