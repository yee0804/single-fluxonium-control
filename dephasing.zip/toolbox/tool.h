#ifndef _TOOL_H_
#define _TOOL_H_

void Complex_vec_inner(double *,double *,double *,int );

void Mat_Multiply(double **,double **,double **,int);

void Complex_Mat_Multiply(double **,double **,double **,int );

void three_Mat_Multiply(double **,double **,double **,double **,int );

void three_Complex_Mat_Multiply(double **,double **,double **,double **,int );

void bracket_expectation(double *,double *,double **,double *,int );

void bracket_expectation_daigO(double *,double *,double *,double *,int );

void Dagger(double **,double **,int );

void Transpose(double **,double **,int N);

double linear_interpolation(double ,double ,double ,double ,double );

#endif /* _TOOL_H_ */
