#ifndef _NRUSE_H_
#define _NRUSE_H_

void Hermitian_eigen(double **,double *,double **,int );

void eigen(double **,double *,double **,int );

void nr_inverse(double **,int );


#endif /* _NRUSE_H_ */
