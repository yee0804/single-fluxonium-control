#ifndef _FUNC_H_
#define _FUNC_H_

void tdep_H(int,int);

void RHS_master_eq(double **,int );

void Dot_Diffeq(double *,double *,int );

void RK4_solver(double*,double ,int );

double dephasing_rate();

#endif
