#include "common.h"


double t,dt;
double rate,rate2;
double **rho,**Had,**Hgrid,**Hadd;
double **sigmap,**sigmam;//sigma plus,minus
double **sigmaz;
double **Mat,*eigval,**trans,**inv_trans,**ptrans;/** for diag, eigval, w, w^-1,w(t-dt) **/
double **diag;//D-matrix after diag(Hgrid)
double phi_ext,dphi_ext,pphi_ext;
double *H0eig1,*H0eig2;
double *phiext_read,*Eg,*E1,*noncoup;
FILE *ffp,*fp,*fp1,*fp2,*fp3,*fp4;
FILE *fpphi;
double D2;

int main()
{
    int i,j,k,step;
    double* Xsolve=vector(0,2*N*N-1);
    rho=matrix(0,N-1,0,2*N-1);
    sigmap=matrix(0,N-1,0,2*N-1);
    sigmam=matrix(0,N-1,0,2*N-1);
    sigmaz=matrix(0,N-1,0,2*N-1);
    Had=matrix(0,N-1,0,2*N-1);
    Hadd=matrix(0,N-1,0,2*N-1);
    Hgrid=matrix(0,Gnum-1,0,Gnum-1);
    eigval=vector(0,Gnum-1);
    trans=matrix(0,Gnum-1,0,Gnum-1);
    inv_trans=matrix(0,Gnum-1,0,Gnum-1);
    ptrans=matrix(0,Gnum-1,0,Gnum-1);

    Mat=matrix(0,N-1,0,N-1);
    diag=matrix(0,N-1,0,N-1);
    
	//fp=fopen("d2_P.txt","w");
    fp=fopen("rho_t_decay.txt","w");
	fp3=fopen("T2.txt","w");
//    fp1=fopen("Had.txt","w");
    fpphi=fopen("sweeping_field.txt","w");


    /* parameter*/
    dt=1e-4;//1e-1;
    rate=1./(3*1e5*2*pi);
	rate2=1./(3*1e2*2*pi);//1./(3*1e5*2*pi);

    /*-- initial condition --*/
	
	Hamiltonian(Hgrid,Gnum);
	eigen(Hgrid,eigval,trans,Gnum);
	
    for(j=0;j<Gnum;j++){
		for(k=0;k<Gnum;k++){
		    ptrans[j][k]=trans[j][k];
		}
    }

    for(i=0;i<N;i++){
		for(j=0;j<2*N;j++){
		    rho[i][j]=0;
		    sigmap[i][j]=0.; sigmam[i][j]=0.;
			sigmaz[i][j]=0;
		}
    }
    
    sigmap[1][0]=1.;sigmam[0][2]=1.;
	sigmaz[0][0]=1.;sigmaz[1][2]=-1.;
    rho[0][0]=1;
	phi_ext=0.5*2*pi;
    pphi_ext=phi_ext;//previous step phi_ext
    
	t=0;
	step=0;
	/*-- end iniital condition --*/

	/*-- read data --*/
	ffp=fopen("adiabatic_info.bin","rb");
	int num_data=21001;
			phiext_read=vector(0,num_data-1);
			Eg=vector(0,num_data-1);
			E1=vector(0,num_data-1);
			noncoup=vector(0,4*num_data-1);

	for(i=0;i<num_data;i++){
		fread(&phiext_read[i],sizeof(double),1,ffp);
		fread(&Eg[i],sizeof(double),1,ffp);
		fread(&E1[i],sizeof(double),1,ffp);
		fread(&noncoup[4*i],sizeof(double),1,ffp);
		fread(&noncoup[4*i+1],sizeof(double),1,ffp);
		fread(&noncoup[4*i+2],sizeof(double),1,ffp);
		fread(&noncoup[4*i+3],sizeof(double),1,ffp);
	}
	dphi_ext=phiext_read[2]-phiext_read[1];
	/*-- end read data --*/
	

    /* master equation solving */
    while(t<T)
    {

		tdep_H(Gnum,N);
		
		/** RK4 **/
		for(i=0;i<N;i++)
		{
		    for(j=0;j<N;j++){
		        Xsolve[i*2*N+2*j]=rho[i][2*j];
		        Xsolve[i*2*N+2*j+1]=rho[i][2*j+1];
		    }
		}
		
		
		RK4_solver(Xsolve,dt,N);
		
		for(i=0;i<N;i++)
		{
		    for(j=0;j<N;j++)
		    {
		        rho[i][2*j]=Xsolve[i*2*N+2*j];
		        rho[i][2*j+1]=Xsolve[i*2*N+2*j+1];
		    }
		}
		
		//save w
		for(j=0;j<N;j++){
		    for(k=0;k<N;k++){
		      	ptrans[j][k]=trans[j][k];
		    }
		}
		/** end RK4 **/
		
		step+=1;
		if(step%1000==0){ printf("t=%lf\n",t);}

		fprintf(fp,"%e %.14e %.14e %.14e %.14e %.14e %.14e %.14e %.14e\n",t,rho[0][0],rho[0][1],rho[0][2],rho[0][3],rho[1][0],rho[1][1],rho[1][2],rho[1][3]);
		

    }


    return 0;
}

